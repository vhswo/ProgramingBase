#pragma once
#include"Card.h"
#include<time.h>
#define RESET 20
#define MAXOPENCARD 2
#define CARDMAX 20
#define STOPTIME 2000
#define EX 0
#define NOW 1

class GameManager
{
private:
	static GameManager* m_GM;
	Card card[CARDMAX];
	std::string GameStart;
	int m_iOpenCardMax;
	int m_iExCard[MAXOPENCARD];
	int m_iScore;
	RECT m_BitMapRect;
	bool m_iGameStartCheck;

	GameManager() {}
public:
	static GameManager* GetInstance()
	{
		if (m_GM == NULL)
			m_GM = new GameManager;
		return m_GM;
	}
	~GameManager() {}

	void Init(HWND hWnd);
	bool Update(HWND hWnd, POINT point);
	void draw(HDC hdc);
	void Release();

	int Win() { return m_iScore; }
	int Suffle(int NumMaxCheck[]);

	bool StartMenuCheck(POINT point);

	void Warm();

};

