#include "GameManager.h"

GameManager* GameManager::m_GM = NULL;

void GameManager::Init(HWND hWnd)
{
	BitMapManager::GetInstance()->Init(hWnd);
	GameStart = "���� ����";
	m_iOpenCardMax = 0;
	m_iExCard[0] = RESET;
	m_iScore = 0;
	m_iGameStartCheck = false;

	m_BitMapRect.left = 250;
	m_BitMapRect.top = 400;
	m_BitMapRect.right = 350;
	m_BitMapRect.bottom = 430;
	/*
	20�� ���� �� ī�忡 �ִ´� 
	������ �������� ī�带 ����
	*/
	
	int NumMaxCheck[IMAGE_END - 1] = { 0 };

	int CardNumber;
	for (int y = 0,CardNumber = 0; y < 4; y++)
	{
		for (int x = 0; x < 5; x++, CardNumber++)
		{
			card[CardNumber].Init((IMAGE)Suffle(NumMaxCheck), 100 + x * 80, 120 + y * 130);
		}
	}
}


int GameManager::Suffle(int NumMaxCheck[])
{
	//�ߺ��� ī�尡 �߸� �ٽ�
	int Random = rand() % (IMAGE_END - 1);
	while (1)
	{
		if (NumMaxCheck[Random] >= MAXOPENCARD)
			Random = rand() % (IMAGE_END - 1);
		else
		{
			NumMaxCheck[Random]++;
			return Random;
		}
	}
}

void GameManager::draw(HDC hdc)
{
	if (m_iGameStartCheck)
	{
		for (int i = 0; i < CARDMAX; i++)
		{
			card[i].Draw(hdc);
		}
	}
	else
	{
		Rectangle(hdc, m_BitMapRect.left, m_BitMapRect.top, m_BitMapRect.right, m_BitMapRect.bottom);
		TextOutA(hdc, 270, 410, GameStart.c_str(), GameStart.length());
	}
}

bool GameManager::Update(HWND hWnd,POINT Point)
{
	if (m_iGameStartCheck && (2 > m_iOpenCardMax))
	{
		for (int i = 0; i < CARDMAX; i++)
		{
			if (card[i].ColliderCheck(Point))
			{
				m_iOpenCardMax++;
				if (m_iExCard[EX] == RESET)
					m_iExCard[EX] = i;
				else
				{
					m_iExCard[NOW] = i;

					if (card[m_iExCard[EX]].GetImageNumber() != card[m_iExCard[NOW]].GetImageNumber())
					{
						SetTimer(hWnd, 1, 2000, NULL);
					}
					else
					{
						m_iOpenCardMax = 0;
						m_iExCard[0] = RESET;
						m_iScore++; // ��������� ��������� ����
					}
					
				}
				return true;
			}
		}
	}
	else
	{
		return StartMenuCheck(Point);
	}
	return false;
}

void GameManager::Release()
{
	delete BitMapManager::GetInstance();
	delete GameManager::GetInstance();
}

bool GameManager::StartMenuCheck(POINT point)
{
	if (PtInRect(&m_BitMapRect, point))
	{
		m_iGameStartCheck = true;
		return true;
	}
	return false;
}

void GameManager::Warm()
{
	card[m_iExCard[EX]].ResetCard();
	card[m_iExCard[NOW]].ResetCard();

	m_iOpenCardMax = 0;
	m_iExCard[0] = RESET;
}
