#pragma once
#include"Crush.h"

#define MAXWIDTH 9100
#define RECT_TOP 290
#define RECT_BOTTOM 280
#define RECT_RIGHT 80
#define BASIC_X 910
#define BASIC_Y 300

class Destination : public Crush
{
private:
	BitMap* m_cDestination;
	fPOINT m_pPoint;
public:
	Destination();
	void Init();
	void Draw(HDC hdc);
	void Update(float deltatime,float playerSpeed,float distance);
	void Release();

};

