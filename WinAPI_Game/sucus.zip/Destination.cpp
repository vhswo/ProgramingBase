#include "Destination.h"
Destination::Destination():
	m_pPoint{ BASIC_X,BASIC_Y }
{
	m_cDestination = BitMapManager::GetInstance()->GetInGameImage(19);
	m_rRect = {0,RECT_BOTTOM,0,RECT_TOP };
}

void Destination::Init()
{
}

void Destination::Draw(HDC hdc)
{
	m_cDestination->fDraw(hdc, m_pPoint, 0,0);
	Rectangle(hdc, m_rRect.left, m_rRect.top, m_rRect.right, m_rRect.bottom);
}

void Destination::Update(float deltatime, float playerSpeed,float distance)
{
	m_pPoint.x = MAXWIDTH - distance;

	m_rRect.left = m_pPoint.x;
	m_rRect.right = m_pPoint.x + RECT_RIGHT;
}

void Destination::Release()
{
}
