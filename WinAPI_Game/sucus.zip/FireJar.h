#pragma once
#include"BitMapManager.h"
#include"Crush.h"

#define Y_LOCATION 300
#define BACK_JAR_LOCATION 980
#define INFRONT_JAR_LOCATION 2660
class FireJar : public Crush
{
private:
	BitMap* m_FireJarBitMap[2];
	fPOINT m_pPoint;
	float m_fFireAnimaitonTimer;
	int m_ifireAnimaion;
	int m_iNowRect;
public:
	FireJar();
	FireJar(int X);
	void Init();
	void Draw(HDC hdc);
	void Update(float deltatime, float PlayerSpeed, float distance, float error);
	void Reset(int x);
	void Release();

};