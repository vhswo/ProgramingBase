#include "FireRing.h"
FireRing::FireRing(int RingStartX):
	m_pPoint{ (float)RingStartX,RING_Y },
	m_fSpeed(SPEED),
	m_iLFireAnimaiton(0),
	m_iRFireAnimaiton(1),
	m_fFireAnimationTimer(0)
{
	for (int i = 15; i < 19; i++)
	{
		m_cFireRingBitMap[i -15] = BitMapManager::GetInstance()->GetInGameImage(i);
	}

	m_rRect = { 0,(LONG)m_pPoint.y + BASIC_RECT_LEFT,0,(LONG)m_pPoint.y + BASIC_RECT_RIGHT };
	m_rScoreRect = { 0, (LONG)m_pPoint.y + 10, 0, (LONG)m_pPoint.y + 115 };
}

void FireRing::Init(){}

void FireRing::Update(float deltatime,float PlayerSpeed, float distance, float error)
{
	if (distance < 0)
	{
		m_pPoint.x += (m_fSpeed - PlayerSpeed) * deltatime;
	}
	else
	{
		m_pPoint.x -= (m_fSpeed - PlayerSpeed) * deltatime;
	}

	if (m_pPoint.x < -RESET)
		m_pPoint.x = RING_START_X;

	m_fFireAnimationTimer += deltatime;
	if(0.05f < m_fFireAnimationTimer)
	{
		m_fFireAnimationTimer = 0;
		m_iLFireAnimaiton+=2;
		if (2 < m_iLFireAnimaiton)m_iLFireAnimaiton = 0;
		m_iRFireAnimaiton+=2;
		if (3 < m_iRFireAnimaiton)m_iRFireAnimaiton = 1;
	}

	m_rRect.left = m_pPoint.x + RECT_LEFT;
	m_rRect.right = m_pPoint.x + RECT_RIGHT;

	m_rScoreRect.left = m_pPoint.x + RECT_LEFT;
	m_rScoreRect.right = m_pPoint.x + RECT_RIGHT;
}

void FireRing::LDraw(HDC hdc)
{
	m_cFireRingBitMap[m_iLFireAnimaiton]->fDraw(hdc, m_pPoint, 0, 0);
}

void FireRing::RDraw(HDC hdc)
{
	fPOINT LDrawXValue;
	LDrawXValue = m_pPoint;
	LDrawXValue.x = m_pPoint.x + IMAGEWITDH;
	m_cFireRingBitMap[m_iRFireAnimaiton]->fDraw(hdc, LDrawXValue, 0, 0);
}

void FireRing::Reset(int RingStartX)
{
	m_pPoint= {(float)RingStartX, RING_Y };
}

void FireRing::Release()
{

}