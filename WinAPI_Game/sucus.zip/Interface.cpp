#include "Interface.h"

Interface::Interface() :
	m_pPoint{ 50,10 },
	m_pLife{0,40},
	m_iScore(0),
	m_iBounsScore(BASEBOUCESCORE),
	m_fBounsScoreTimer(0.0f),
	m_strTitleScore("Score : "),
	m_strTitleBonus("Bonus : "),
	m_strScore(to_string(m_iScore)),
	m_strBounsScore(to_string(m_iBounsScore)),
	m_pStreetLength{ { 0,HEIGHT_LOCATION }, {WITDHMAX,HEIGHT_LOCATION} },
	ShowMeter(START1),
	ShowMeter2(START2)
{
	m_cInterfaceBitMap[0] = BitMapManager::GetInstance()->GetInGameImage(6);
	m_cInterfaceBitMap[1] = BitMapManager::GetInstance()->GetInGameImage(7);
	m_cInterfaceBitMap[2] = BitMapManager::GetInstance()->GetInGameImage(8);
	font = CreateFont(20, 0, 0, 0, 0, 0, 0, 0, HANGEUL_CHARSET, 0, 0, 0, 0, L"�ü�");
}

void Interface::Init(HDC hdc){}

void Interface::Update(float deltatime, float CharSpeed,float distance, float error)
{
	m_strScore = to_string(m_iScore);
	m_fBounsScoreTimer += deltatime;
	if (0.15f < m_fBounsScoreTimer)
	{
		m_fBounsScoreTimer = 0;

		if (m_iBounsScore > 0) m_iBounsScore -= SCORE;
		m_strBounsScore = to_string(m_iBounsScore);
	}
	if (distance < DISTANCEMAX)
	{
		if (distance < 0)
		{
			m_pStreetLength[0].x -= error;
			m_pStreetLength[1].x -= error;
		}
		else
		{
			m_pStreetLength[0].x += (CharSpeed * deltatime);
			m_pStreetLength[1].x += (CharSpeed * deltatime);
		}

		if (m_pStreetLength[0].x < -WITDHMAX)
		{
			m_pStreetLength[0].x = WITDHMAX + m_pStreetLength[1].x;
			ShowMeter -= CHANGEMETER;
		}
		if (m_pStreetLength[1].x < -WITDHMAX)
		{
			m_pStreetLength[1].x = WITDHMAX + m_pStreetLength[0].x;
			ShowMeter2 -= CHANGEMETER;
		}

		if (m_pStreetLength[0].x > WITDHMAX)
		{
			m_pStreetLength[0].x = m_pStreetLength[1].x - WITDHMAX;
			ShowMeter += CHANGEMETER;
		}
		if (m_pStreetLength[1].x > WITDHMAX)
		{
			m_pStreetLength[1].x = m_pStreetLength[0].x - WITDHMAX;
			ShowMeter2 += CHANGEMETER;
		}

	}
}

void Interface::Draw(HDC hdc,int Life)
{	
	oldfont = (HFONT)SelectObject(hdc, font);
	m_cInterfaceBitMap[0]->Draw(hdc, m_pPoint, 0);
	SetTextColor(hdc, RGB(255, 255, 255));
	SetBkColor(hdc, RGB(0, 0, 0));
	TextOutA(hdc, 200, 30, m_strTitleScore.c_str(), m_strTitleScore.length());
	TextOutA(hdc, 300, 30, m_strScore.c_str(), m_strScore.length());
	TextOutA(hdc, 500, 30, m_strTitleBonus.c_str(), m_strTitleBonus.length());
	TextOutA(hdc, 600, 30, m_strBounsScore.c_str(), m_strBounsScore.length());
	for (int i = 0; i < Life; i++)
	{
		m_pLife.x = STARTDRAWLIFE + (i * 15);
		m_cInterfaceBitMap[1]->Draw(hdc, m_pLife, 0);
	}
	
	m_cInterfaceBitMap[2]->fDraw(hdc, m_pStreetLength[0], 0,0);
	m_cInterfaceBitMap[2]->fDraw(hdc, m_pStreetLength[1], 0,0);

	TextOutA(hdc, m_pStreetLength[0].x + 15, m_pStreetLength[0].y + 5, to_string(ShowMeter).c_str(), to_string(ShowMeter).length());
	TextOutA(hdc, m_pStreetLength[1].x + 15, m_pStreetLength[1].y + 5, to_string(ShowMeter2).c_str(), to_string(ShowMeter2).length());

	SelectObject(hdc, oldfont);
}

void Interface::GetScore(int score)
{
	m_iScore += score;
}

void Interface::Reset(WINDIE WinOrDie)
{
	switch (WinOrDie)
	{
	case WINDIE_WIN:
	case WINDIE_DIE:
		ShowMeter = START1;
		ShowMeter2 = START2;
		m_iScore = 0;
		m_iBounsScore = BASEBOUCESCORE;
		m_pStreetLength[0] = { 0,HEIGHT_LOCATION };
		m_pStreetLength[1] = { WITDHMAX, HEIGHT_LOCATION };
		break;
	case WINDIE_DECREASELIF:
		if (m_pStreetLength[0].x > 0)
			m_pStreetLength[0].x = WITDHMAX;
		if (m_pStreetLength[1].x > 0)
			m_pStreetLength[1].x = WITDHMAX;
		if (m_pStreetLength[0].x < 0)
			m_pStreetLength[0].x = 0;
		if (m_pStreetLength[1].x < 0)
			m_pStreetLength[1].x = 0;
		break;
	}
}

void Interface::EndGame(WINDIE WinOrDie)
{
	switch (WinOrDie)
	{
	case WINDIE_WIN:
		if (m_iBounsScore > 0)
		{
			m_iBounsScore -= SCORE;
			m_iScore += SCORE;
			m_strScore = to_string(m_iScore);
			m_strBounsScore = to_string(m_iBounsScore);
		}
		break;
	case WINDIE_DIE:
	case WINDIE_DECREASELIF:
		break;
	}
}

void Interface::Release()
{
}
