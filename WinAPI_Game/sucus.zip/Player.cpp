#include "Player.h"
Player::Player() :
	m_eInputState(INPUTSTATE_NONE),
	m_eAnimaionState(ANIMATIONSTATE_IDLE),
	m_pCharacterPoint{ PLAYERSTART_X, IDLE },
	CharAnimationTimer(0),
	m_iSpeed(CHARACTERSPEED),
	m_iJumpState(true),
	m_iMoveAnimation(0),
	m_bBenMove(false),
	CharRect{0,0,0,0},
	m_iLife(LIFE),
	m_Run(0),
	WinAnimation(0)
{
	for (int i = 9; i < 15; i++)
	{
		m_cCharacterBitMap[i - 9] = BitMapManager::GetInstance()->GetInGameImage(i);
	}
}

void Player::Init(){}

float Player::Update(float deltatime, float distance)
{
	if (m_eAnimaionState != ANIMATIONSTATE_JUMP)
	{
		if (GetAsyncKeyState(VK_SPACE) & 0x8000)
		{
 			m_eAnimaionState = ANIMATIONSTATE_JUMP;
			CharAnimationTimer = 0.02f;
			return m_Run;
		}

		if (GetAsyncKeyState(VK_RIGHT) & 0x8000)
		{
			m_eInputState = INPUTSTATE_RIGHT;
		}
		else if (GetAsyncKeyState(VK_LEFT) & 0x8000)
		{
			m_eInputState = INPUTSTATE_LEFT;
		}
		else
		{
			m_eInputState = INPUTSTATE_NONE;
			m_eAnimaionState = ANIMATIONSTATE_IDLE;
		}
		m_eAnimaionState = ANIMATIONSTATE_RUN;
	}
	else
	{
		JumpAnimaiton();
	}
	
	m_Run = GetDirection() * CHARACTERSPEED * deltatime;

	CharAnimationTimer += deltatime;
	if (0.02f < CharAnimationTimer)
	{
		CharAnimationTimer = 0;
		if(distance >= GOALINROUND)
			m_Run = Move(deltatime, distance);
		MoveAnimation();
	}

	CharRect.left = m_pCharacterPoint.x + CRUSH_LEFT;
	CharRect.right = m_pCharacterPoint.x + CRUSH_RIGHT;
	CharRect.top = m_pCharacterPoint.y;
	CharRect.bottom = m_pCharacterPoint.y + CRUSH_HIGH;

	return m_Run;
}

void Player::Draw(HDC hdc)
{
	m_cCharacterBitMap[m_iMoveAnimation]->fDraw(hdc, m_pCharacterPoint, 0,0);
}

void Player::MoveAnimation()
{
	switch (m_eAnimaionState)
	{
	case ANIMATIONSTATE_RUN:
		m_iMoveAnimation++;
		if (m_iMoveAnimation > (2 - m_eInputState))
			m_iMoveAnimation = MOTION_IDEL;
		break;
	case ANIMATIONSTATE_JUMP:
		m_iMoveAnimation = MOTION_JUMP;
		break;
	case INPUTSTATE_NONE:
		m_iMoveAnimation = MOTION_IDEL;
		break;
	case ANIMATIONSTATE_DIE:
		m_iMoveAnimation = MOTION_DIE;
		break;
	case ANIMATIONSTATE_WIN:
		m_iMoveAnimation = MOTION_WIN + WinAnimation;
		WinAnimation++;
		if (WinAnimation > 1) WinAnimation = 0;
		break;
	}

}

void Player::JumpAnimaiton()
{
	if (m_pCharacterPoint.y <= MAXJUMP) m_iJumpState = false;

	if (m_iJumpState) m_pCharacterPoint.y -= JUMPTURM;
	else m_pCharacterPoint.y += JUMPTURM;

	if (m_pCharacterPoint.y >= IDLE)
	{
		m_iJumpState = true;
		m_eAnimaionState = ANIMATIONSTATE_IDLE;
	}
}

float Player::Get_Speed(float distance)
{
	if (distance < GOALINROUND)
	{
		return -GetDirection() * CHARACTERSPEED;
	}

	return 0;
}

int Player::GetDirection()
{
	switch (m_eInputState)
	{
	case INPUTSTATE_RIGHT:
		return 1;
	case INPUTSTATE_LEFT:
		return -1;
	default: return 0;
	}
}

float Player::Move(float deltaTime, float distance)
{
	m_pCharacterPoint.x += m_Run;
	if (distance + m_Run < GOALINROUND)
	{
		float error = GOALINROUND - distance;
		m_pCharacterPoint.x = PLAYERSTART_X;
		
		return error;
	}
	if (distance + m_Run >= MAXWIDTH)
	{
		float error = MAXWIDTH - distance;
		m_pCharacterPoint.x = PLAYERMAX_X;
	
		return error;
	}

	return m_Run;
}

bool Player::EndGame(WINDIE windie)
{
	switch (windie)
	{
	case WINDIE_WIN:
		m_pCharacterPoint.y = WIN_Y;
		m_pCharacterPoint.x = WIN_X;
		m_eAnimaionState = ANIMATIONSTATE_WIN;
		MoveAnimation();
		return true;
		break;
	case WINDIE_DIE:
	case WINDIE_DECREASELIF:
		m_eAnimaionState = ANIMATIONSTATE_DIE;
		m_eInputState = INPUTSTATE_NONE;
		break;
	}
	
	MoveAnimation();
	return false;
}



void Player::Reset(WINDIE windie)
{
	switch (windie)
	{
	case WINDIE_WIN:
	case WINDIE_DIE:
		m_iLife = LIFE;
		break;
	case WINDIE_DECREASELIF:
		m_iLife--;
		break;
	}
	m_eAnimaionState = ANIMATIONSTATE_IDLE;
	m_eInputState = INPUTSTATE_NONE;
	m_pCharacterPoint.x = PLAYERSTART_X;
	m_pCharacterPoint.y = IDLE;
	m_iJumpState = true;
}

RECT &Player::Get_Rectangle()
{
	return CharRect;
}

void Player::Release()
{

}