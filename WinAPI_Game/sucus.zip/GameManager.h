#ifndef GameManager
#include"BitMapManager.h"
#include"StartMenu.h"
#include"InGame.h"
class GameManager
{
private:
	static GameManager* m_cInstance;
	HWND m_hWnd;
	HDC m_hdc, m_backDc;
	int Width, height;
	bool m_bInGame;

	GameManager() {}
public:
	~GameManager() {}
	static GameManager* get_Instance()
	{
		if (m_cInstance == NULL)
		{
			m_cInstance = new GameManager;
		}
		return m_cInstance;
	}
	void Init(HWND hWnd);
	void Update(float deltaTime);
	void Draw();
	void Release();
private:
	void DoubleBuffer();
	HBITMAP CreateDIBSectionRe(HDC hdc, int width, int height);
};
#endif // !GameManager