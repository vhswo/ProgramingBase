#include "InGame.h"

InGame* InGame::m_IGame = NULL;

void InGame::Init()
{
	m_cBK.Init();

	for (int i = 0; i < BIG_FIRERING_MAX; i++)
	{
		m_cBigFireRing.push_back(new FireRing(FIRERING_START_LOCATION + (i* FIRERING_BETWEEN_DISTANCE)));
	}
	for (int i = 0; i < FIREJAR_MAX; i++)
	{
		m_cFireJar.push_back(new FireJar(FIREJAR_START_LOCATION + (i* FIREJAR_BETWEEN_DISTANCE)));
	}
	m_cSmallFireRing = new SmallFireRing();
	m_fStreetLength = 0;
	CrushCheck = true;
	m_eEndGame = WINDIE_DECREASELIF;
	m_iTimer = 0;
	m_fEndGameTimer = 0;
	for (int i = 0; i < 21; i++)
	{
		m_cInGameBitMap[i] = BitMapManager::GetInstance()->GetInGameImage(i);
	}
}

void InGame::Draw(HDC hdc)
{
	m_cBK.Draw(hdc);

	if (m_eEndGame != WINDIE_WIN)
	{
		for (int i = 0; i < m_cBigFireRing.size(); i++)
		{
			m_cBigFireRing[i]->LDraw(hdc);
		}
		m_cSmallFireRing->LDraw(hdc);

	}

	if (m_fStreetLength >= CREATE_DESTINATION)
		m_cDestination.Draw(hdc);

	for (int i = 0; i < FIREJAR_MAX; i++)
	{
		m_cFireJar[i]->Draw(hdc);
	}
	m_cPlayer.Draw(hdc);
	if (m_eEndGame != WINDIE_WIN)
	{
		for (int i = 0; i < m_cBigFireRing.size(); i++)
		{
			m_cBigFireRing[i]->RDraw(hdc);
		}
		m_cSmallFireRing->RDraw(hdc);
	}
	m_cInterface.Draw(hdc, m_cPlayer.Get_Life());


	// �ѱ��� �׽�Ʈ
	string tmp;
	tmp = to_string(m_fStreetLength);
	TextOutA(hdc, 100, 360, tmp.c_str(), tmp.length());
}
bool InGame::Update(float deltatime, HDC hdc)
{
	//���� ȹ�� ������ üũ
	for (int i = 0; i < BIG_FIRERING_MAX; i++)
	{
		m_cBigFireRing[i]->GetScoreDelay(deltatime);
	}
	m_cSmallFireRing->GetScoreDelay(deltatime);
	for (int i = 0; i < FIREJAR_MAX; i++)
	{
		m_cFireJar[i]->GetScoreDelay(deltatime);
	}

	if (CrushCheck)
	{
		float ExDistance = m_cPlayer.Update(deltatime, m_fStreetLength);
		m_fStreetLength += ExDistance;
		MaxScreen = m_fStreetLength / WITDH;
		ExDistance -= m_fStreetLength; // ���� ���� ���ϱ�
		if (m_fStreetLength < 8300)
		{
			m_cBK.Update(deltatime, m_cPlayer.Get_Speed(m_fStreetLength), m_fStreetLength, ExDistance);
			
			for (int i = 0; i < FIREJAR_MAX; i++)
			{
				m_cFireJar[i]->Update(deltatime, m_cPlayer.Get_Speed(m_fStreetLength), m_fStreetLength, ExDistance);
			}
			m_cDestination.Update(deltatime, m_cPlayer.Get_Speed(m_fStreetLength), m_fStreetLength);

		}

		//ū�� ����
		for (int i = 0; i < m_cBigFireRing.size(); i++)
		{
			m_cBigFireRing[i]->Update(deltatime, m_cPlayer.Get_Speed(m_fStreetLength), m_fStreetLength, ExDistance);
		}
		m_cSmallFireRing->Update(deltatime, m_cPlayer.Get_Speed(m_fStreetLength), m_fStreetLength, ExDistance);
		m_cSmallFireRing->GoldReset();

		if (m_fStreetLength < 0) // �ѰŸ��� 0���� ������ 0���� ����
			m_fStreetLength -= m_fStreetLength;


		//�浹üũ
		Crush();

		m_cInterface.Update(deltatime, m_cPlayer.Get_Speed(m_fStreetLength), m_fStreetLength, ExDistance);
	}
	else
	{
		m_fEndGameTimer += deltatime;
		m_iTimer += deltatime;

		m_cInterface.EndGame(m_eEndGame);
		if (3.0f > m_iTimer)
		{
			if (0.1f < m_fEndGameTimer)
			{
				m_fEndGameTimer = 0;
				if (m_cPlayer.EndGame(m_eEndGame))
					m_cBK.Win();
			}
		}
		else
		{
			if (m_eEndGame == WINDIE_WIN && m_cInterface.GetBonuceScore() > 0)
				return true;

			if (m_cPlayer.Get_Life() <= 1)
				m_eEndGame = WINDIE_DIE;

			m_cPlayer.Reset(m_eEndGame); //�÷��̾� ����
			//�׾Ƹ� �ʱ�ȭ
			//�Ҹ� �ʱ�ȭ
			for (int i = 0; i < FIREJAR_MAX; i++)
			{
				m_cFireJar[i]->Reset(FIREJAR_START_LOCATION + (i * FIREJAR_BETWEEN_DISTANCE));
			}

			for (int i = 0; i < BIG_FIRERING_MAX; i++)
			{
				m_cBigFireRing[i]->Reset(FIRERING_START_LOCATION + (i * FIRERING_BETWEEN_DISTANCE));
			}

			m_cSmallFireRing->Reset(SMALL_FIRERING_START_LOCATION);

			m_cBK.Reset(); // ��� ����
			m_cInterface.Reset(m_eEndGame); //�������̽� �ʱ�ȭ

			CrushCheck = true;

			m_iTimer = 0; //������ �¸� �ִϸ��̼�Ÿ�̸� �ʱ�ȭ

			m_fStreetLength = MaxScreen * WITDH;

			if (m_eEndGame == WINDIE_DIE || m_eEndGame == WINDIE_WIN)
			{
				//��������
				m_fStreetLength = 0;
				m_eEndGame = WINDIE_DECREASELIF;
				return false;
			}
		}
	}
	return true;
}

void InGame::Crush()
{
	//�¸� üũ
	if (m_cDestination.CrushCheck(m_cPlayer.Get_Rectangle()))
	{
		CrushCheck = false;
		m_eEndGame = WINDIE_WIN;
	}

	if (CrushCheck)
	{
		//ū��
		for (int i = 0; i < BIG_FIRERING_MAX; i++)
		{
			if (m_cBigFireRing[i]->GetScore(m_cPlayer.Get_Rectangle())) m_cInterface.GetScore(100);
			if (m_cBigFireRing[i]->CrushCheck(m_cPlayer.Get_Rectangle())) CrushCheck = false;
		}

		//������
		if (m_cSmallFireRing->GetScore(m_cPlayer.Get_Rectangle()))
		{
			m_cInterface.GetScore(1000);
			m_cSmallFireRing->CheckCrushGold();
		}
		if (m_cSmallFireRing->CrushCheck(m_cPlayer.Get_Rectangle())) CrushCheck = false;

		//�׾Ƹ�
		for (int i = 0; i < FIREJAR_MAX; i++)
		{
			if (m_cFireJar[i]->GetScore(m_cPlayer.Get_Rectangle())) m_cInterface.GetScore(100);
			if (m_cFireJar[i]->CrushCheck(m_cPlayer.Get_Rectangle())) CrushCheck = false;
		}
	}
}

void InGame::Release()
{
}

/*

���� �ؾߵɰ�

���� ������ �ʱ�ȭ
���� �ʱ�ȭ

�¸� �Ÿ� ����
�¸��� �׾������ ����Ѱ� ��ġ��
*/