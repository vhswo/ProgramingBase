#include "FireJar.h"
FireJar::FireJar(int X) :
	m_pPoint{(float)X,Y_LOCATION },
	m_fFireAnimaitonTimer(0),
	m_ifireAnimaion(0),
	m_iNowRect(0)
{
	m_FireJarBitMap[0] = BitMapManager::GetInstance()->GetInGameImage(4);
	m_FireJarBitMap[1] = BitMapManager::GetInstance()->GetInGameImage(5);

	m_rRect = { 0,(LONG)m_pPoint.y + 5 ,0,(LONG)m_pPoint.y + 30 };
	m_rScoreRect = {0,(LONG)m_pPoint.y - 40,0,(LONG)m_pPoint.y};
}

void FireJar::Init(){}


void FireJar::Draw(HDC hdc) 
{
	m_FireJarBitMap[m_ifireAnimaion]->fDraw(hdc, m_pPoint, 0,0);
	/*Rectangle(hdc, m_rRect.left, m_rRect.top, m_rRect.right, m_rRect.bottom);
	Rectangle(hdc, m_rScoreRect.left, m_rScoreRect.top, m_rScoreRect.right, m_rScoreRect.bottom);*/

	//// �׽�Ʈ
	//string tmp;
	//tmp = to_string(m_pPoint.x);
	//TextOutA(hdc, 250+i, 360, tmp.c_str(), tmp.length());
	//tmp = to_string(m_iNowRect);
	//TextOutA(hdc, 450, 360, tmp.c_str(), tmp.length());
	
}

void FireJar::Update(float deltatime,float PlayerSpeed, float distance, float error)
{
	m_fFireAnimaitonTimer += deltatime;
	if (0.05f < m_fFireAnimaitonTimer)
	{
		m_fFireAnimaitonTimer = 0;
		m_ifireAnimaion++;
		if (m_ifireAnimaion > 1)
			m_ifireAnimaion = 0;
	}

	if (distance < 0)
	{
		m_pPoint.x -= error;
	}
	else
	{
		m_pPoint.x += (PlayerSpeed * deltatime);
	}

	if (m_pPoint.x < -BACK_JAR_LOCATION)
		m_pPoint.x = 1750 + (m_pPoint.x + BACK_JAR_LOCATION);
	if (m_pPoint.x > INFRONT_JAR_LOCATION)
		m_pPoint.x = -70 + (INFRONT_JAR_LOCATION - m_pPoint.x);

	m_rRect.left = m_pPoint.x + 10;
	m_rRect.right = m_pPoint.x + 40;

	m_rScoreRect.left = m_rRect.left;
	m_rScoreRect.right = m_rRect.right;

	//m_rScoreRect.left = m_pPoint.x + 10;
	//m_rScoreRect.right = m_pPoint.x + 40;
}

void FireJar::Reset(int x)
{
	m_pPoint = { (float)x,Y_LOCATION };
}