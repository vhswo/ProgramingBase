#pragma once
#include"BitMapManager.h"
class Crush
{
protected:
	RECT m_rTmp,m_rRect, m_rScoreRect;
	float m_fDelayTimer;
	bool m_bPossibleGetScoer;
public:
	Crush();
	bool CrushCheck(RECT& Player);
	bool GetScore(RECT& Player);
	void GetScoreDelay(float deltatime);
};

