#pragma once
#include"BitMapManager.h"

enum INPUTSTATE
{
	INPUTSTATE_RIGHT,
	INPUTSTATE_LEFT,
	INPUTSTATE_NONE
};
enum ANIMATIONSTATE
{
	ANIMATIONSTATE_RUN,
	ANIMATIONSTATE_JUMP,
	ANIMATIONSTATE_IDLE,
	ANIMATIONSTATE_DIE,
	ANIMATIONSTATE_WIN
};

enum MOTION
{
	MOTION_IDEL,
	MOTION_JUMP = 2,
	MOTION_WIN,
	MOTION_DIE = 5
};

#define MAXJUMP 205
#define IDLE 285
#define CHARACTERSPEED 300
#define WIN_X 810
#define WIN_Y 240
#define MAXWIDTH 9100
#define GOALINROUND 8300
#define PLAYERSTART_X 30
#define PLAYERMAX_X 830
#define CRUSH_LEFT 20
#define CRUSH_RIGHT 40
#define CRUSH_HIGH 50
#define LIFE 5
#define JUMPTURM 10

class Player
{
private:
	INPUTSTATE m_eInputState;
	ANIMATIONSTATE m_eAnimaionState;
	fPOINT m_pCharacterPoint;
	BitMap* m_cCharacterBitMap[6];
	RECT CharRect;
	int m_iMoveAnimation, WinAnimation;
	int m_iLife;
	bool m_iJumpState; //���� ����üũ
	bool m_bBenMove; // �ڷ� �̵�����
	float m_iSpeed,m_fPlayerSpeed;
	float CharAnimationTimer;
	float m_Run;
public:
	Player();
	void Init();
	float Update(float deltatime, float distance);
	void Draw(HDC hdc);
	void Release();
	void MoveAnimation();
	void JumpAnimaiton();
	float Move(float deltaTime, float distance);
	bool EndGame(WINDIE windie);
	int Get_Life() { return m_iLife; }
	float Get_Speed(float distance);
	int GetDirection();
	void Reset(WINDIE windie);
	RECT &Get_Rectangle();
};

