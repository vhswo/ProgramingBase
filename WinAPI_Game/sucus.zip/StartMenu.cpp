#include "StartMenu.h"

StartMenu* StartMenu::m_SM = NULL;

void StartMenu::Init()
{
	inputTimer = 0;
	starAnimationTimer = 0;
	// 0 ~ 3 Ÿ��Ʋ
	// 4 ~ 8 �޴�
	// 9 ������
	for (int i = 0; i < STARTIMAGE_END; i++)
	{
		BitMap[i] = BitMapManager::GetInstance()->GetImage(i);
	}

	int i = 0;
	m_j = 1;
	count = 2;
	
	m_titlePoint = { 330, 65 };
	m_pPoint = { 240 , 260 };

	for (int y = 0; y < 6; y++)
	{
		for (int x = 0; x < 16; x++)
		{
			if (y == 0 || y == 5)
			{
				m_point[i].x = 315 + x * 15;
				m_point[i].y = 50 + y * 15;
				i++;
			}
			else
			{
				if (x == 0 || x == 15)
				{
					m_point[i].x = 300 + x * 17;
					m_point[i].y = 50 + y * 15;
					i++;
				}
			}
		}
	}
	int baseLocation = 230;
	for (int y = 0; y < 5; y++)
	{
		if (y == 0)
			baseLocation = 180;
		else
			baseLocation = 230;
		m_pMenu[y].x = 315;
		m_pMenu[y].y = baseLocation + y*30;
	}
}

void StartMenu::draw(HDC hdc)
{
	BitMap[STARTIMAGE_MAINTITLE]->Draw(hdc, m_titlePoint,0);

	int i;
	for (i = 0; i < 44; i++, m_j++)
	{
		if (m_j > 3) m_j = 1;
		BitMap[m_j]->Draw(hdc,m_point[i],0);
	}
	for (i = STARTIMAGE_MENUSTART; i <= STARTIMAGE_MENUEND; i++)
	{
		BitMap[i]->Draw(hdc, m_pMenu[i - 4],0);
	}

	BitMap[STARTIMAGE_POINT]->Draw(hdc, m_pPoint,0);
}

bool StartMenu::Update(HDC hdc, float deltatime)
{
	starAnimationTimer += deltatime;
	if(0.1f <= starAnimationTimer)
	{
		starAnimationTimer = 0;

		count++;
		if (count > 2)
			count = 0;
	}
	switch (count)
	{
	case 0: m_j = 2; break;
	case 1: m_j = 3; break;
	default: m_j = 1; break;
	}

	inputTimer -= deltatime;
	if (0.0f >= inputTimer)
	{
		inputTimer = 0.1f;

		if (GetAsyncKeyState(VK_RETURN))
		{
			return true;
		}

		if (GetAsyncKeyState(VK_DOWN))
		{
			if (m_pPoint.y < 350)
				m_pPoint.y += 30;
		}
		else if (GetAsyncKeyState(VK_UP))
		{
			if (m_pPoint.y > 260)
				m_pPoint.y -= 30;
		}
	}

	return false;
}
void StartMenu::Release()
{
}