#include "GameManager.h"
GameManager* GameManager::m_cInstance = NULL;

void GameManager::Init(HWND hWnd)
{
	m_hWnd = hWnd;
	m_hdc = GetDC(hWnd);
	m_backDc = CreateCompatibleDC(m_hdc);
	m_bInGame = false;
	
	RECT windowRect;
	GetWindowRect(m_hWnd, &windowRect);
	Width = windowRect.right - windowRect.left;
	height = windowRect.bottom - windowRect.top;

	BitMapManager::GetInstance()->Init(m_hWnd);
	StartMenu::Get_Instance()->Init();
	InGame::Get_Instance()->Init();
}

void GameManager::Update(float deltaTime)
{
	switch (m_bInGame)
	{
	case false:
		m_bInGame = StartMenu::Get_Instance()->Update(m_backDc, deltaTime);
		break;
	case true:
		m_bInGame = InGame::Get_Instance()->Update(deltaTime, m_backDc);
		break;
	}
}

void GameManager::Draw()
{
	DoubleBuffer();
}

void GameManager::Release()
{
	InGame::Get_Instance()->Release();

	DeleteObject(m_backDc);
	ReleaseDC(m_hWnd, m_hdc);
}

void GameManager::DoubleBuffer()
{
	HBITMAP backBitmap = CreateDIBSectionRe(m_hdc, Width, height);	
	SelectObject(m_backDc, backBitmap);

	switch (m_bInGame)
	{
	case false:
		StartMenu::Get_Instance()->draw(m_backDc);
		break;
	case true:
		InGame::Get_Instance()->Draw(m_backDc);
		break;
	}

	BitBlt(m_hdc, 0, 0, Width, height, m_backDc, 0, 0, SRCCOPY);

	DeleteObject(backBitmap);
}

HBITMAP GameManager::CreateDIBSectionRe(HDC hdc, int width, int height)
{
	BITMAPINFO bm_info;
	ZeroMemory(&bm_info.bmiHeader, sizeof(BITMAPINFOHEADER));
	bm_info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bm_info.bmiHeader.biBitCount = 24;
	bm_info.bmiHeader.biWidth = width;
	bm_info.bmiHeader.biHeight = height;
	bm_info.bmiHeader.biPlanes = 1;

	LPVOID pBits;
	return CreateDIBSection(hdc, &bm_info, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
}