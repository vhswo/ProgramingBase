#include "BitMapManager.h"

BitMapManager* BitMapManager::m_hThis = NULL;

BitMapManager::BitMapManager()
{
	m_parrBitMap = new BitMap[10];
	m_parrInGameBitMap = new BitMap[21];
}


void BitMapManager::Init(HWND hWnd)
{
	char buf[256];
	HDC hdc = GetDC(hWnd);
	for (int i = 0; i < 10; i++)
	{
		if(i >= 0 &&i <4)
		{
			sprintf_s(buf, "bmp/title_%d.bmp", i+1);
		}
		else if (i >= 4 && i < 9)
		{
			sprintf_s(buf, "bmp/menu_%d.bmp", i - 3);
		}
		else
		{
			sprintf_s(buf, "bmp/point.bmp");
		}
		m_parrBitMap[i].Init(hdc, buf);
	}

	for (int i = 0; i < 21; i++)
	{
		if (i >= 0 && i < 4)
		{
			sprintf_s(buf, "bmp/back_%d.bmp", i + 1);
		}
		else if (i >= 4 && i < 6)
		{
			sprintf_s(buf, "bmp/fire_%d.bmp", i - 3);
		}
		else if (i >= 6 && i < 9)
		{
			sprintf_s(buf, "bmp/interface_%d.bmp", i - 5);
		}
		else if (i >= 9 && i < 15)
		{
			sprintf_s(buf, "bmp/player_%d.bmp", i - 8);
		}
		else if (i >= 15 && i < 19)
		{
			sprintf_s(buf, "bmp/ring_%d.bmp", i - 14);
		}
		else if (i == 19)
		{
			sprintf_s(buf, "bmp/goal.bmp");
		}
		else
		{
			sprintf_s(buf, "bmp/cash.bmp");
		}

		m_parrInGameBitMap[i].Init(hdc, buf);
	}

	ReleaseDC(hWnd, hdc);
}

BitMapManager::~BitMapManager()
{
	delete[] m_parrBitMap;
	delete[] m_parrInGameBitMap;
}
