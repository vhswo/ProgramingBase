#include "Crush.h"
Crush::Crush() :
	m_bPossibleGetScoer(true),
	m_fDelayTimer(0)
{

}
bool Crush::CrushCheck(RECT& Player)
{
	if (IntersectRect(&m_rTmp, &Player, &m_rRect))
	{
		return true;
	}
	return false;
}

bool Crush::GetScore(RECT& Player)
{
	if (m_bPossibleGetScoer)
	{
		if (IntersectRect(&m_rTmp, &Player, &m_rScoreRect))
		{
			m_bPossibleGetScoer = false;
			return true;
		}
	}
	return false;
}

void Crush::GetScoreDelay(float deltatime)
{
	if (m_bPossibleGetScoer == false)
	{
		m_fDelayTimer += deltatime;
		if (0.2f < m_fDelayTimer)
		{
			m_fDelayTimer = 0;
			m_bPossibleGetScoer = true;
		}
	}
}