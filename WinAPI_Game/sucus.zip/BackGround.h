#pragma once
#include"BitMapManager.h"
class BackGround
{
private:
	BitMap* m_cBackGroundBitMap[4];
	POINT m_pUpPoint, m_pUpPoint2, m_pDownPoint;
	float ScreenX1, ScreenX2 ;
	int PeopleState;
public:
	BackGround();
	void Init();
	void Update(float deltatime,float speed,float distance,float distance1);
	void Draw(HDC hdc);
	void Reset();
	void Win();
	void Release();
};

