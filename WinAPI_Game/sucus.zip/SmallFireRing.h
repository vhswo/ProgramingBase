#pragma once
#include"FireRing.h"
class SmallFireRing : public FireRing 
{
private:
	BitMap* m_cGold;
	fPOINT m_pGoldPoint, LDrawXValue;
	bool DrawGold;

public:
	SmallFireRing();
	void Init(){}
	void LDraw(HDC hdc);
	void RDraw(HDC hdc);
	void CheckCrushGold() { DrawGold = false; }
	void GoldReset();
	void Reset(int RingStartX);
	void Release(){}
};

