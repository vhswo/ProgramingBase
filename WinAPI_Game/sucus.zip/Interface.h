#pragma once
#ifndef InferFace
#include"BitMapManager.h"
#define START1 100
#define START2 90

#define CHANGEMETER 20
#define BASEBOUCESCORE 5000
#define WITDHMAX 910
#define HEIGHT_LOCATION 350
#define SCORE 10
#define STARTDRAWLIFE 750
#define DISTANCEMAX 8300

class Interface
{
private:
	BitMap* m_cInterfaceBitMap[3];
	POINT m_pPoint,m_pLife;
	fPOINT m_pStreetLength[2];
	HFONT font, oldfont;
	int m_iScore, m_iBounsScore;
	int ShowMeter, ShowMeter2;
	float m_fBounsScoreTimer;
	string m_strTitleScore, m_strTitleBonus,m_strScore,m_strBounsScore;
public:
	Interface();
	void Init(HDC hdc);
	void Update(float deltatime, float CharSpeed,float distance, float error);
	void Draw(HDC hdc, int Life);
	void EndGame(WINDIE WinOrDie);
	void Reset(WINDIE WinOrDie);
	void GetScore(int score);
	int GetBonuceScore(){ return m_iBounsScore; }
	void Release();
};

#endif // !InferFace