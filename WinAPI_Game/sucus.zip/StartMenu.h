#pragma once
#include"BitMapManager.h"

enum STARTIMAGE
{
	STARTIMAGE_START = 0,

	STARTIMAGE_MAINTITLE = 0,
	STARTIMAGE_TITLSTARONE,
	STARTIMAGE_TITLTHREE,
	STARTIMAGE_TITLEEND,

	STARTIMAGE_MENUSTART = 4,
	STARTIMAGE_PLYAER_SELECT = 4,
	STARTIMAGE_1PA,
	STARTIMAGE_1PB,
	STARTIMAGE_2PA,
	STARTIMAGE_2PB = 8,
	STARTIMAGE_MENUEND = 8,

	STARTIMAGE_POINT,

	STARTIMAGE_END
};



class StartMenu
{
private:
	static StartMenu* m_SM;

	StartMenu(){}
	BitMap* BitMap[10];
	POINT m_point[44],m_titlePoint,m_pMenu[5],m_pPoint;
	int m_j,count;
	float inputTimer, starAnimationTimer;
public:
	static StartMenu* Get_Instance()
	{
		if (NULL == m_SM)
		{
			m_SM = new StartMenu;
		}
		return m_SM;
	}
	void Init();
	void draw(HDC hdc);
	bool Update(HDC hdc, float deltatime);
	void Release();
};

