#pragma once
#ifndef BitManager
#include"BitMap.h"
#include<string>
#include<vector>
using namespace std;

enum WINDIE
{
	WINDIE_WIN= 1,
	WINDIE_DIE,
	WINDIE_DECREASELIF
};

class BitMapManager
{
private:
	BitMap* m_parrBitMap,*m_parrInGameBitMap;
	static BitMapManager* m_hThis;
	BitMapManager();
public:
	static BitMapManager* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new BitMapManager;
		return m_hThis;
	}
	BitMap* GetImage(int index)
	{
		return &m_parrBitMap[index];
	}
	BitMap* GetInGameImage(int index)
	{
		return &m_parrInGameBitMap[index];
	}
	void Init(HWND hWnd);
	~BitMapManager();
};


#endif // !BitManager