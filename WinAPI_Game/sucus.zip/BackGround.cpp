#include "BackGround.h"
BackGround::BackGround() :
	m_pUpPoint{ 0,0 },
	m_pUpPoint2{ 0,0 },
	m_pDownPoint{ 0, 0 },
	ScreenX1(0),
	ScreenX2(14 * 66),
	PeopleState(2)
{
	for (int i = 0; i < 4; i++)
	{
		m_cBackGroundBitMap[i] = BitMapManager::GetInstance()->GetInGameImage(i);
	}
}

void BackGround::Init()
{
	m_pDownPoint.y += 167;
	m_pUpPoint.y += 100;
	m_pUpPoint2.y += 100;
}

void BackGround::Update(float deltatime, float speed,float distance,float ExDistance)
{
	if (distance < 0)
	{
		ScreenX1 -= ExDistance;
		ScreenX2 -= ExDistance;
	}
	else
	{
		ScreenX1 += (speed * deltatime);
		ScreenX2 += (speed * deltatime);
	}
	
	if (ScreenX1 < -910)
		ScreenX1 = ScreenX2 + (14 * 66);
	if(ScreenX2 < -910)
		ScreenX2 = ScreenX1 + (14 * 66);
	if(ScreenX1 > 910)
		ScreenX1 = ScreenX2 - (14 * 66);
	if (ScreenX2 > 910)
		ScreenX2 = ScreenX1 - (14 * 66);
}

void BackGround::Draw(HDC hdc)
{
	m_cBackGroundBitMap[0]->Draw(hdc, m_pDownPoint, 900);

	for (int i = 0; i < 14; i++)
	{
		m_pUpPoint.x = ScreenX1 + (i * 66);
		if (i % 7 == 3)
			m_cBackGroundBitMap[1]->Draw(hdc, m_pUpPoint, 0);
		else
			m_cBackGroundBitMap[PeopleState]->Draw(hdc, m_pUpPoint, 0);
	}
	for (int i = 0; i < 14; i++)
	{
		m_pUpPoint2.x = ScreenX2 + (i * 66);
		if (i % 7 == 2)
			m_cBackGroundBitMap[1]->Draw(hdc, m_pUpPoint2, 0);
		else
			m_cBackGroundBitMap[PeopleState]->Draw(hdc, m_pUpPoint2, 0);
	}

	//�����ġ Ȯ��
	string tmp;
	tmp = to_string(ScreenX1);
	string tmp2;
	tmp2 = to_string(ScreenX2);
	TextOutA(hdc, 250, 360, tmp.c_str(), tmp.length());
	TextOutA(hdc, 350, 360, tmp2.c_str(), tmp.length());
}

void BackGround::Reset()
{
	ScreenX1 = 0;
	ScreenX2 = (14 * 66);
	PeopleState = 2;
}

void BackGround::Win()
{
	PeopleState++;
	if (PeopleState > 3)
		PeopleState = 2;
}

void BackGround::Release()
{
}

