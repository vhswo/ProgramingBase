// �ΰ��� cpp Ȯ�οϷ� ���� Ȯ�� 

#include"GameManager.h"
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("First");

int g_nGetKeyX = 0, g_nGetAsyncKeyX = 0;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	g_hInst = hInstance;

	WNDCLASS WndClass;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);	//����
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);	//Ŀ��
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);	//������ ���
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;	//���μ��� �Լ� ȣ��
	WndClass.lpszClassName = lpszClass;	//Ŭ���� �̸�
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	HWND hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, 910, 440,
		NULL, (HMENU)NULL, hInstance, NULL);

	if (!hWnd) return 0;

	ShowWindow(hWnd, nCmdShow);

	GameManager::get_Instance()->Init(hWnd);
	
	ULONGLONG FPS = 30;     // Frame Per Seconds
	float invFPS = 1000.0f / FPS;  // 1�� : 1000

	ULONGLONG frameTime, limitFrameTime = 0;

	MSG Message;
	ZeroMemory(&Message, sizeof(Message));
	while (WM_QUIT != Message.message)
	{
		if (PeekMessage(&Message, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}
		else
		{
			frameTime = GetTickCount64();
			if (limitFrameTime <= frameTime)
			{
				float deltaTime = (frameTime - limitFrameTime + invFPS) * 0.001f;
				limitFrameTime = frameTime + invFPS;

				GameManager::get_Instance()->Update(deltaTime);
				GameManager::get_Instance()->Draw();
			}
		}
	}
	GameManager::get_Instance()->Release();

	return (int)Message.wParam;
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
