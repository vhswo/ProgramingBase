#pragma once
#include"Crush.h"
#define RING_Y 167
#define RING_START_X 2070
#define BASIC_RECT_LEFT 120
#define BASIC_RECT_RIGHT 132
#define RESET 400
#define RECT_LEFT 20
#define RECT_RIGHT 36
#define SPEED 100
#define IMAGEWITDH 26

class FireRing : public  Crush
{
protected:
	BitMap* m_cFireRingBitMap[4];
	fPOINT m_pPoint;
	float m_fSpeed;
	int m_iLFireAnimaiton;
	int m_iRFireAnimaiton;
	float m_fFireAnimationTimer;
public:
	FireRing(){}
	FireRing(int RingStartX);
	void Init();
	void LDraw(HDC hdc);
	void RDraw(HDC hdc);
	virtual void Update(float deltatime, float PlayerSpeed, float distance, float error);
	void Reset(int RingStartX);
	void Release();
};