#include "SmallFireRing.h"

SmallFireRing::SmallFireRing() : 
	DrawGold(true)
{
	m_cGold = BitMapManager::GetInstance()->GetInGameImage(20);

	for (int i = 15; i < 19; i++)
	{
		m_cFireRingBitMap[i - 15] = BitMapManager::GetInstance()->GetInGameImage(i);
	}

	m_pPoint = { 2070,167 };
	m_rRect = { (LONG)m_pPoint.x+20, (LONG)m_pPoint.y + 100, 
		(LONG)m_pPoint.x + 36, (LONG)m_pPoint.y + 112 };
	m_rScoreRect = { (LONG)m_pPoint.x + 20, (LONG)m_pPoint.y + 10,
		(LONG)m_pPoint.x + 36, (LONG)m_pPoint.y + 105 };
	m_fSpeed = 150;
}
void SmallFireRing::Reset(int RingStartX)
{
	m_pPoint = { (float)RingStartX, RING_Y };
	DrawGold = true;
}

void SmallFireRing::GoldReset()
{
	if(m_pPoint.x < -350)
		DrawGold = true;
}

void SmallFireRing::LDraw(HDC hdc)
{
	m_cFireRingBitMap[m_iLFireAnimaiton]->fDraw(hdc, m_pPoint, 0,-20);
	if (DrawGold)
	{
		m_pGoldPoint.x = m_pPoint.x + 13;
		m_pGoldPoint.y = m_pPoint.y + 25;
		m_cGold->fDraw(hdc, m_pGoldPoint, 0, 0);
	}
}
void SmallFireRing::RDraw(HDC hdc)
{
	LDrawXValue = m_pPoint;
	LDrawXValue.x = m_pPoint.x + 26;
	m_cFireRingBitMap[m_iRFireAnimaiton]->fDraw(hdc, LDrawXValue, 0, -20);

	//Rectangle(hdc, m_rRect.left, m_rRect.top, m_rRect.right, m_rRect.bottom);
	//Rectangle(hdc, m_rScoreRect.left, m_rScoreRect.top, m_rScoreRect.right, m_rScoreRect.bottom);
}