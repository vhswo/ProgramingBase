#pragma once
#include"Player.h"
#include"BackGround.h"
#include"SmallFireRing.h"
#include"FireJar.h"
#include"Interface.h"
#include"Destination.h"

#define CREATE_DESTINATION 8190
#define BIG_FIRERING_MAX 4
#define FIREJAR_MAX 3
#define FIRERING_START_LOCATION 870
#define FIRERING_BETWEEN_DISTANCE 600
#define FIREJAR_BETWEEN_DISTANCE 910
#define FIREJAR_START_LOCATION 840
#define WITDH 910
#define SMALL_FIRERING_START_LOCATION 2070

class InGame
{
private:
	static InGame* m_IGame;

	BitMap* m_cInGameBitMap[21];
	
	float m_fEndGameTimer,m_iTimer;
	float m_fStreetLength;
	bool CrushCheck;
	int MaxScreen;

	WINDIE m_eEndGame;

	vector<FireJar*> m_cFireJar;
	vector<FireRing*> m_cBigFireRing;
	SmallFireRing* m_cSmallFireRing;
	Destination m_cDestination;
	BackGround m_cBK;
	Interface m_cInterface;
	Player m_cPlayer;

	InGame() {}
public:
	static InGame* Get_Instance()
	{
		if (m_IGame == NULL)
			m_IGame = new InGame;
		return m_IGame;
	}
	void Init();
	void Draw(HDC hdc);
	bool Update(float deltatime,HDC hdc);
	void Crush();
	void Release();

};

/*
	���      0 ~ 3  0 Ǯ�� 1 �ڳ��� 2 ���� 3 �ڼ�����
	��        4 ~ 5
	�������̽� 6 ~ 8 // 8 �Ÿ���
	ĳ����     9 ~ 14
	��        15 ~ 18
	��         19
	��         20
*/

