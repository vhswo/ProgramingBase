#pragma comment(lib,"ws2_32.lib") 
#define WINSOCK_DEPRECATED_NO_WARNINGS

#include<WinSock2.h>
#include<iostream>
#include<vector>
#include<algorithm>
std::vector<SOCKET> g_vSocket;

#define MAX_BUFFER_SIZE 256

void err_display(const char* msg);
void err_quit(const char* msg);

DWORD WINAPI ProcessClient(LPVOID arg);
HANDLE g_hMutex;

#pragma pack(1)
typedef struct
{
	char cName[64];
}Packet;
#pragma pack()

int main()
{
	g_hMutex = CreateMutex(NULL, false, NULL);
	if (NULL == g_hMutex) return -1;
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		CloseHandle(g_hMutex);
		return -1;
	}

	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return -1;
	
	SOCKET listen_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (INVALID_SOCKET == listen_socket) err_quit("socket");


	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(9000);
	serveraddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);


	if (bind(listen_socket, (SOCKADDR*)&serveraddr, sizeof(serveraddr)) == SOCKET_ERROR)
	{
		closesocket(listen_socket);
		WSACleanup();
		err_quit("bind");
	}
	// listen() ���� ��⿭ ����.
	if (listen(listen_socket, SOMAXCONN) == SOCKET_ERROR)
	{
		closesocket(listen_socket);
		WSACleanup();
		err_quit("listen");
	}

	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(SOCKADDR_IN);
	ZeroMemory(&clientaddr, addrlen);

	SOCKET client_socket;
	HANDLE hThread;
	DWORD threadID;

	while (1)
	{
		client_socket = accept(listen_socket, (SOCKADDR*)&clientaddr, &addrlen);
		if (INVALID_SOCKET == client_socket) continue;

		printf("\n[TCP ����] Ŭ���̾�Ʈ ���� : IP �ּ�=%s, ��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));

		WaitForSingleObject(g_hMutex, INFINITE);
		g_vSocket.push_back(client_socket);
		ReleaseMutex(g_hMutex);

		hThread = CreateThread(NULL, 0, ProcessClient, (LPVOID)client_socket, 0, &threadID);
		if (NULL == hThread) std::cout << "[����] ������ ���� ����!" << std::endl;
		else CloseHandle(hThread);

	}

	closesocket(listen_socket);

	WSACleanup();

	CloseHandle(g_hMutex);
}

void err_quit(const char* msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	// msg : �޽��� �ڽ��� Ÿ��Ʋ(Caption)
	MessageBox(NULL, (LPCSTR)lpMsgBuf, msg, MB_ICONERROR);
	// �޸� ����, �ڵ� ��ȿȭ.
	LocalFree(lpMsgBuf);
	exit(-1);
}

void err_display(const char* msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s\n", msg, (LPCSTR)lpMsgBuf);
	LocalFree(lpMsgBuf);
}

DWORD WINAPI ProcessClient(LPVOID arg)
{
	SOCKET client_sock = (SOCKET)arg;
	SOCKADDR_IN clientaddr;
	int addrlen = sizeof(clientaddr);
	getpeername(client_sock, (SOCKADDR*)&clientaddr, &addrlen);
	int retval;
	char buf[sizeof(Packet)];
	while (1)
	{
		ZeroMemory(buf, sizeof(buf));
		// ������ �ޱ�.
		retval = recv(client_sock, buf, sizeof(buf), 0);
		if (SOCKET_ERROR == retval) break;
		else if (0 == retval) break;
		
		Packet* recv_packet = (Packet*)buf;

		printf("\n[TCP%s:%d] %s\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port),
			recv_packet->cName);

		WaitForSingleObject(g_hMutex, INFINITE);
		for (const auto& sock : g_vSocket)
		{
			retval = send(sock, buf, sizeof(Packet), 0);
			if (SOCKET_ERROR == retval) break;
		}
		ReleaseMutex(g_hMutex);
		if (SOCKET_ERROR == retval) break;
	}

	WaitForSingleObject(g_hMutex, INFINITE);
	auto itr = std::find(g_vSocket.begin(), g_vSocket.end(), client_sock);
	if (g_vSocket.end() != itr) g_vSocket.erase(itr);
	ReleaseMutex(g_hMutex);

	closesocket(client_sock);
	printf("\n[TCP ����] Ŭ���̾�Ʈ ���� : IP �ּ�=%s, ��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
	return 0;
}