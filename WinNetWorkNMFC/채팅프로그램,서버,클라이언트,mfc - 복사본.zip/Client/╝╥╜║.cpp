#pragma comment(lib,"ws2_32.lib")

#define WINSOCK_DEPRECATED_NO_WARNINGS

#include<WinSock2.h>
#include<iostream>
#include<string>

#define MAX_BUFFER_SIZE 256

using namespace std;

void err_display(const char* msg);
void err_quit(const char* msg);

#pragma pack(1)
typedef struct
{
	char cName[10];
}Packet;
#pragma pack()

int main()
{
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return -1;

	SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
	if (INVALID_SOCKET == sock) return -1;

	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(9000);
	serveraddr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");

	if(SOCKET_ERROR == connect(sock, (SOCKADDR*)&serveraddr,
		sizeof(serveraddr))) err_quit("connect");

	int len, retval;
	char buf[sizeof(Packet)];
	Packet* p = (Packet*)buf;
	while (1)
	{
		ZeroMemory(buf, sizeof(buf));
		printf("\n[���� ������]");
		cin >> p->cName;

		retval = send(sock, (char*)p, sizeof(Packet), 0);
		if (SOCKET_ERROR == retval) break;

		ZeroMemory(buf, sizeof(buf));
		retval = recv(sock, buf, sizeof(Packet), 0);
		if (SOCKET_ERROR == retval) break;
		else if (0 == retval) break;

		printf("[���� ������] %s\n", p->cName);
	}

	closesocket(sock);

	WSACleanup();
}


void err_quit(const char* msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);

	MessageBox(NULL, (LPCSTR)lpMsgBuf, msg, MB_ICONERROR);

	LocalFree(lpMsgBuf);

	exit(-1);
}

void err_display(const char* msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);

	printf("[%s] %s\n", msg, (LPCSTR)lpMsgBuf);

	LocalFree(lpMsgBuf);
}